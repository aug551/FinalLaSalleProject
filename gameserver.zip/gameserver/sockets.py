import socket;
import json;
import hashlib
from mycrypt.crypt import Crypto

crypto = Crypto()

class Socket:

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def __init__(self, port):
        self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.s.bind(('', port))
        self.s.listen(5)

    def Login(self, username):
        player = json.loads(username)
        try:
            file = open(f"players/{player['username']}.json")
            data = json.load(file)
            
            if data['password'] == crypto.EncryptPassword(player['password'].encode()):
                msg = json.dumps(data)
                print(f"Sending {player['username']}\'s data.")
            else:
                msg = "wrong_password"

        except IOError:
            msg = "not_found"
            print("Player doesn't exist")

        return msg

    def CreateAccount(self, account):
        newP = json.loads(account)
        try:
            file = open(f"players/{newP['username']}.json")
            msg = "already_exists"
            print('Player already exists.')
        except IOError:
            file = open(f"players/{newP['username']}.json", "w")
            newP['password'] = crypto.EncryptPassword(newP['password'].encode())
            file.write(json.dumps(newP, sort_keys=True, indent=4))
            msg = "player_created"
            print("New player created.")

        file.close()
        
        return msg

    def SaveGame(self, username):
        player = json.loads(username)
        try:
            file = open(f"players/{player['username']}.json", "w")
            file.write(json.dumps(player, sort_keys=True, indent=4))
            msg = "saved"
            print("SaveGame")
        except IOError:
            msg = "Error, not found"
            print("Couldn't find player")

        file.close()
        return msg

    def ClientThread(self, connection, lock):
        while True:
            _ff = connection.recv(1024)
            # print(_ff)
            try:
                firstmsg = _ff.decode('ascii')
                if firstmsg.startswith("GetKey"):
                    connection.sendall(self.GetPublicKey())
                    testenc = connection.recv(1024)
                    print(crypto.DecryptMessage(testenc))
                    # connection.sendall(crypto.SignMessage(self.GetPublicKey()))
            except UnicodeDecodeError:
                ff = crypto.DecryptMessage(_ff)
                ffstr = ff.decode('ascii')

                if ffstr.startswith("Open"):
                    ffstr = ffstr[4:]
                    toSend = self.Login(ffstr).encode('ascii')
                    connection.sendall(toSend)

                if ffstr.startswith("Create"):
                    ffstr = ffstr[6:]
                    connection.sendall(self.CreateAccount(ffstr).encode('ascii'))

                if ffstr.startswith("Save"):
                    ffstr = ffstr[4:]
                    connection.sendall(self.SaveGame(ffstr).encode('ascii'))

            connection.close()
            lock.release()
            break

    def GetPublicKey(self):
        return crypto.GetPublicKey()