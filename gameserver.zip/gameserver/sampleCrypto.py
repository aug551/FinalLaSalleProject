from mycrypt.crypt import Crypto

crypto = Crypto()

plaintext = b"Meawto gay"

# Encrypting text
encrypted = crypto.EncryptMessage(plaintext)

# Signing
signature = crypto.SignMessage(plaintext)

# Verifying
isSigned = crypto.Verify(encrypted, signature)


# Decrypting
decrypted = crypto.DecryptMessage(encrypted)
print(decrypted)
